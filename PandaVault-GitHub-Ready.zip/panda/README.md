# Panda Vault

Android privacy vault project built with Kotlin, Jetpack Compose, Room and Android Keystore.

## GitHub automatic APK build

1. Create a GitHub repository.
2. Upload the **contents of this folder** (do not create an extra nested `panda` folder).
3. Push to `main` or `master`.
4. Open the repository's **Actions** tab.
5. Open **Build Panda Vault APK**.
6. When the job finishes, download **Panda-Vault-debug-apk** from Artifacts.

The workflow installs Gradle 8.9 and uses JDK 17, so a Gradle wrapper is not required for GitHub Actions.

## Local Android Studio build

Open the project root in Android Studio and let Gradle sync. Build the debug APK with:

`gradle :app:assembleDebug`

## Important

The App Lock feature relies on Android Usage Access and overlay permissions. Android controls which apps can actually be locked or hidden; the app does not use root access.
