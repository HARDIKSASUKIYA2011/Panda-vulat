package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.security.CryptoManager
import com.example.data.security.SecurityPreferences
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Panda Vault", appName)
  }

  @Test
  fun `verify pin hashing and validation`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val prefs = SecurityPreferences(context)
    prefs.setPin("1234")
    assertTrue(prefs.verifyPin("1234"))
  }
}
