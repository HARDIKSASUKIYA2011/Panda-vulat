package com.example.ui.screens

import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.ScreenLockPortrait
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.localization.AppLanguage
import com.example.localization.Strings
import com.example.ui.components.PandaTopBar
import com.example.ui.navigation.Screen
import com.example.ui.theme.BambooEmerald
import com.example.ui.viewmodel.VaultViewModel

@Composable
fun SettingsScreen(
    viewModel: VaultViewModel,
    language: AppLanguage,
    onBackClick: () -> Unit,
    onChangePinClick: () -> Unit
) {
    val context = LocalContext.current
    val biometricEnabled by viewModel.biometricEnabled.collectAsState()
    val flagSecureEnabled by viewModel.flagSecureEnabled.collectAsState()
    val autoLockTimeout by viewModel.autoLockTimeout.collectAsState()
    val themeMode by viewModel.themeMode.collectAsState()
    val stats by viewModel.stats.collectAsState()

    var showAutoLockDialog by remember { mutableStateOf(false) }
    var showOfflinePledgeDialog by remember { mutableStateOf(false) }
    var showAboutDialog by remember { mutableStateOf(false) }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            PandaTopBar(
                title = Strings.get("nav_settings", language),
                language = language,
                onBackClick = onBackClick
            )

            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                // Section: Security
                item {
                    Text(
                        text = "Security & Protection",
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = BambooEmerald
                        )
                    )
                }

                item {
                    SettingsCard {
                        // Change PIN
                        SettingsClickableRow(
                            icon = Icons.Default.Lock,
                            title = Strings.get("change_pin", language),
                            subtitle = "Update your 4–6 digit master PIN",
                            testTag = "settings_change_pin",
                            onClick = onChangePinClick
                        )

                        // Biometric
                        SettingsSwitchRow(
                            icon = Icons.Default.Fingerprint,
                            title = Strings.get("biometric_title", language),
                            subtitle = Strings.get("biometric_desc", language),
                            checked = biometricEnabled,
                            testTag = "settings_biometric_switch",
                            onCheckedChange = { viewModel.setBiometricEnabled(it) }
                        )

                        // Auto-Lock Timeout
                        SettingsClickableRow(
                            icon = Icons.Default.Timer,
                            title = Strings.get("auto_lock_title", language),
                            subtitle = when (autoLockTimeout) {
                                0 -> Strings.get("lock_immediately", language)
                                30 -> "After 30 seconds"
                                60 -> "After 1 minute"
                                else -> "After 5 minutes"
                            },
                            testTag = "settings_autolock",
                            onClick = { showAutoLockDialog = true }
                        )

                        // Flag Secure (Screenshots)
                        SettingsSwitchRow(
                            icon = Icons.Default.ScreenLockPortrait,
                            title = Strings.get("flag_secure_title", language),
                            subtitle = Strings.get("flag_secure_desc", language),
                            checked = flagSecureEnabled,
                            testTag = "settings_flag_secure",
                            onCheckedChange = { viewModel.setFlagSecure(it) }
                        )
                    }
                }

                // Section: Preferences & Language
                item {
                    Text(
                        text = Strings.get("language_title", language),
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = BambooEmerald
                        )
                    )
                }

                item {
                    SettingsCard {
                        // Language Selection
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Language,
                                    contentDescription = null,
                                    tint = BambooEmerald
                                )
                                Spacer(modifier = Modifier.width(14.dp))
                                Text(
                                    text = Strings.get("language_title", language),
                                    style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.SemiBold)
                                )
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilterChip(
                                    selected = language == AppLanguage.ENGLISH,
                                    onClick = { viewModel.setLanguage(AppLanguage.ENGLISH) },
                                    label = { Text("English") },
                                    modifier = Modifier.testTag("lang_english")
                                )
                                FilterChip(
                                    selected = language == AppLanguage.GUJARATI,
                                    onClick = { viewModel.setLanguage(AppLanguage.GUJARATI) },
                                    label = { Text("ગુજરાતી") },
                                    modifier = Modifier.testTag("lang_gujarati")
                                )
                            }
                        }

                        // Theme Mode
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Palette,
                                    contentDescription = null,
                                    tint = BambooEmerald
                                )
                                Spacer(modifier = Modifier.width(14.dp))
                                Text(
                                    text = "Theme",
                                    style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.SemiBold)
                                )
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilterChip(
                                    selected = themeMode == "dark",
                                    onClick = { viewModel.setThemeMode("dark") },
                                    label = { Text("Dark") }
                                )
                                FilterChip(
                                    selected = themeMode == "light",
                                    onClick = { viewModel.setThemeMode("light") },
                                    label = { Text("Light") }
                                )
                            }
                        }
                    }
                }

                // Section: Storage & Privacy
                item {
                    Text(
                        text = "Storage & Privacy",
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = BambooEmerald
                        )
                    )
                }

                item {
                    SettingsCard {
                        SettingsClickableRow(
                            icon = Icons.Default.Storage,
                            title = "Encrypted Vault Storage",
                            subtitle = "${stats.totalItems} files • ${formatFileSize(stats.totalSizeBytes)}",
                            testTag = "settings_storage",
                            onClick = {
                                Toast.makeText(context, "Encrypted in local private storage (AES-256)", Toast.LENGTH_SHORT).show()
                            }
                        )

                        SettingsClickableRow(
                            icon = Icons.Default.VerifiedUser,
                            title = "100% Offline Pledge",
                            subtitle = "Zero servers, no tracking, zero internet required",
                            testTag = "settings_offline_pledge",
                            onClick = { showOfflinePledgeDialog = true }
                        )

                        SettingsClickableRow(
                            icon = Icons.Default.Info,
                            title = "About Panda Vault",
                            subtitle = "App Hider & Locker v1.0.0",
                            testTag = "settings_about",
                            onClick = { showAboutDialog = true }
                        )
                    }
                }
            }
        }
    }

    if (showAutoLockDialog) {
        AlertDialog(
            onDismissRequest = { showAutoLockDialog = false },
            title = { Text(Strings.get("auto_lock_title", language), fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    listOf(
                        0 to Strings.get("lock_immediately", language),
                        30 to "30 Seconds",
                        60 to "1 Minute",
                        300 to "5 Minutes"
                    ).forEach { (seconds, label) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.setAutoLockTimeout(seconds)
                                    showAutoLockDialog = false
                                }
                                .padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = autoLockTimeout == seconds,
                                onClick = {
                                    viewModel.setAutoLockTimeout(seconds)
                                    showAutoLockDialog = false
                                }
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(text = label, style = MaterialTheme.typography.bodyLarge)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showAutoLockDialog = false }) {
                    Text(Strings.get("cancel", language))
                }
            },
            shape = RoundedCornerShape(16.dp)
        )
    }

    if (showOfflinePledgeDialog) {
        AlertDialog(
            onDismissRequest = { showOfflinePledgeDialog = false },
            title = { Text("100% Offline & Private", fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "Panda Vault operates entirely on your physical device.\n\n" +
                            "• All photos, videos and files are encrypted with AES-256 GCM using Android's hardware Keystore.\n" +
                            "• No files or passwords are ever sent to the cloud or any third-party server.\n" +
                            "• Zero analytics, zero ad SDKs, and zero telemetry.",
                    style = MaterialTheme.typography.bodyMedium
                )
            },
            confirmButton = {
                TextButton(onClick = { showOfflinePledgeDialog = false }) {
                    Text(Strings.get("confirm", language))
                }
            },
            shape = RoundedCornerShape(16.dp)
        )
    }

    if (showAboutDialog) {
        AlertDialog(
            onDismissRequest = { showAboutDialog = false },
            title = { Text(Strings.get("app_title", language), fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "Panda Vault – App Hider & Locker\n" +
                            "Version 1.0.0 (Bilingual Gujarati + English)\n\n" +
                            "Crafted with modern Jetpack Compose, Room Database, and Android Keystore AES-GCM encryption.\n\n" +
                            "Notice: In accordance with Android security policies, launcher app hiding is done via real-time Usage Access and Overlay interception without altering OS system files.",
                    style = MaterialTheme.typography.bodyMedium
                )
            },
            confirmButton = {
                TextButton(onClick = { showAboutDialog = false }) {
                    Text(Strings.get("confirm", language))
                }
            },
            shape = RoundedCornerShape(16.dp)
        )
    }
}

@Composable
fun SettingsCard(content: @Composable () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(vertical = 4.dp)) {
            content()
        }
    }
}

@Composable
fun SettingsClickableRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    testTag: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp)
            .testTag(testTag),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(imageVector = icon, contentDescription = null, tint = BambooEmerald)
        Spacer(modifier = Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.SemiBold))
            Text(text = subtitle, style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant))
        }
    }
}

@Composable
fun SettingsSwitchRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    testTag: String,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 14.dp)
            .testTag(testTag),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(imageVector = icon, contentDescription = null, tint = BambooEmerald)
        Spacer(modifier = Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.SemiBold))
            Text(text = subtitle, style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant))
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = BambooEmerald
            )
        )
    }
}
