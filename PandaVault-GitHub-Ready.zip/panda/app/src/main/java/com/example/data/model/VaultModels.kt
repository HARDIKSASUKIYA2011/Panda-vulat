package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class VaultFileType {
    PHOTO,
    VIDEO,
    DOCUMENT,
    OTHER
}

@Entity(tableName = "vault_items")
data class VaultItem(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val fileName: String,
    val originalPath: String? = null,
    val vaultPath: String,
    val fileType: String, // PHOTO, VIDEO, DOCUMENT, OTHER
    val mimeType: String,
    val fileSize: Long,
    val createdAt: Long = System.currentTimeMillis(),
    val folderId: Long,
    val isDeleted: Boolean = false,
    val deletedAt: Long? = null,
    val isEncrypted: Boolean = true
)

@Entity(tableName = "vault_folders")
data class VaultFolder(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val type: String, // PHOTO, VIDEO, DOCUMENT, GENERAL
    val createdAt: Long = System.currentTimeMillis(),
    val iconName: String = "folder",
    val isSystem: Boolean = false
)

@Entity(tableName = "locked_apps")
data class LockedApp(
    @PrimaryKey
    val packageName: String,
    val appName: String,
    val isLocked: Boolean = true,
    val lockedAt: Long = System.currentTimeMillis()
)

data class VaultStats(
    val totalItems: Int = 0,
    val photoCount: Int = 0,
    val videoCount: Int = 0,
    val documentCount: Int = 0,
    val fileCount: Int = 0,
    val totalSizeBytes: Long = 0L,
    val lockedAppsCount: Int = 0,
    val trashCount: Int = 0
)
