package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Panda Vault Dark Palette (Default Privacy Mode)
val PandaDarkBackground = Color(0xFF090D16)
val PandaDarkSurface = Color(0xFF111827)
val PandaDarkCard = Color(0xFF1E293B)
val PandaDarkCardHover = Color(0xFF27354A)
val PandaDarkBorder = Color(0xFF334155)

val BambooEmerald = Color(0xFF10B981)
val BambooEmeraldDark = Color(0xFF065F46)
val BambooEmeraldLight = Color(0xFF34D399)
val BambooMint = Color(0xFF6EE7B7)

val PandaGold = Color(0xFFF59E0B)
val PandaGoldLight = Color(0xFFFDE68A)
val PandaCyan = Color(0xFF06B6D4)
val PandaPurple = Color(0xFF8B5CF6)
val PandaRose = Color(0xFFF43F5E)

// Panda Vault Light Palette
val PandaLightBackground = Color(0xFFF8FAFC)
val PandaLightSurface = Color(0xFFFFFFFF)
val PandaLightCard = Color(0xFFF1F5F9)
val PandaLightBorder = Color(0xFFE2E8F0)
val PandaLightPrimary = Color(0xFF059669)

val TextPrimaryDark = Color(0xFFF8FAFC)
val TextSecondaryDark = Color(0xFF94A3B8)
val TextMutedDark = Color(0xFF64748B)

val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF475569)
val TextMutedLight = Color(0xFF94A3B8)
