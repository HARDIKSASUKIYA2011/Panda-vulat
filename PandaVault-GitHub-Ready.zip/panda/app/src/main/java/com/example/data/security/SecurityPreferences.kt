package com.example.data.security

import android.content.Context
import android.content.SharedPreferences
import com.example.localization.AppLanguage

class SecurityPreferences(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("panda_vault_security_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_IS_PIN_SET = "is_pin_set"
        private const val KEY_PIN_HASH = "pin_hash"
        private const val KEY_PIN_SALT = "pin_salt"
        private const val KEY_BIOMETRIC_ENABLED = "biometric_enabled"
        private const val KEY_FLAG_SECURE = "flag_secure_enabled"
        private const val KEY_AUTOLOCK_TIMEOUT = "autolock_timeout" // seconds: 0 = immediate, 30, 60, 300
        private const val KEY_LANGUAGE = "app_language"
        private const val KEY_THEME = "app_theme" // "system", "dark", "light"
        private const val KEY_SEC_QUESTION = "security_question"
        private const val KEY_SEC_ANSWER_HASH = "security_answer_hash"
        private const val KEY_SEC_ANSWER_SALT = "security_answer_salt"
        private const val KEY_RECOVERY_KEY = "recovery_key"
        private const val KEY_LAST_BACKGROUND_TIME = "last_background_time"
        private const val KEY_IS_LOCKED = "is_app_locked_state"
    }

    var isPinSet: Boolean
        get() = prefs.getBoolean(KEY_IS_PIN_SET, false)
        set(value) = prefs.edit().putBoolean(KEY_IS_PIN_SET, value).apply()

    var biometricEnabled: Boolean
        get() = prefs.getBoolean(KEY_BIOMETRIC_ENABLED, false)
        set(value) = prefs.edit().putBoolean(KEY_BIOMETRIC_ENABLED, value).apply()

    var flagSecureEnabled: Boolean
        get() = prefs.getBoolean(KEY_FLAG_SECURE, true)
        set(value) = prefs.edit().putBoolean(KEY_FLAG_SECURE, value).apply()

    var autoLockTimeoutSeconds: Int
        get() = prefs.getInt(KEY_AUTOLOCK_TIMEOUT, 0)
        set(value) = prefs.edit().putInt(KEY_AUTOLOCK_TIMEOUT, value).apply()

    var language: AppLanguage
        get() {
            val code = prefs.getString(KEY_LANGUAGE, "en") ?: "en"
            return if (code == "gu") AppLanguage.GUJARATI else AppLanguage.ENGLISH
        }
        set(value) = prefs.edit().putString(KEY_LANGUAGE, value.code).apply()

    var themeMode: String
        get() = prefs.getString(KEY_THEME, "system") ?: "system"
        set(value) = prefs.edit().putString(KEY_THEME, value).apply()

    var securityQuestion: String
        get() = prefs.getString(KEY_SEC_QUESTION, "") ?: ""
        set(value) = prefs.edit().putString(KEY_SEC_QUESTION, value).apply()

    var recoveryKey: String
        get() = prefs.getString(KEY_RECOVERY_KEY, "") ?: ""
        set(value) = prefs.edit().putString(KEY_RECOVERY_KEY, value).apply()

    var isVaultLocked: Boolean
        get() = prefs.getBoolean(KEY_IS_LOCKED, true)
        set(value) = prefs.edit().putBoolean(KEY_IS_LOCKED, value).apply()

    var lastBackgroundTime: Long
        get() = prefs.getLong(KEY_LAST_BACKGROUND_TIME, 0L)
        set(value) = prefs.edit().putLong(KEY_LAST_BACKGROUND_TIME, value).apply()

    fun setPin(pin: String) {
        val salt = CryptoManager.generateSalt()
        val hash = CryptoManager.hashWithSalt(pin, salt)
        prefs.edit()
            .putString(KEY_PIN_SALT, salt)
            .putString(KEY_PIN_HASH, hash)
            .putBoolean(KEY_IS_PIN_SET, true)
            .apply()
    }

    fun verifyPin(pin: String): Boolean {
        val salt = prefs.getString(KEY_PIN_SALT, null) ?: return false
        val hash = prefs.getString(KEY_PIN_HASH, null) ?: return false
        val computedHash = CryptoManager.hashWithSalt(pin, salt)
        return computedHash == hash
    }

    fun setSecurityQuestionAndAnswer(question: String, answer: String) {
        val salt = CryptoManager.generateSalt()
        val answerHash = CryptoManager.hashWithSalt(answer.trim().lowercase(), salt)
        val recoveryKey = CryptoManager.generateRecoveryKey()
        prefs.edit()
            .putString(KEY_SEC_QUESTION, question)
            .putString(KEY_SEC_ANSWER_SALT, salt)
            .putString(KEY_SEC_ANSWER_HASH, answerHash)
            .putString(KEY_RECOVERY_KEY, recoveryKey)
            .apply()
    }

    fun verifySecurityAnswer(answer: String): Boolean {
        val salt = prefs.getString(KEY_SEC_ANSWER_SALT, null) ?: return false
        val expectedHash = prefs.getString(KEY_SEC_ANSWER_HASH, null) ?: return false
        val computedHash = CryptoManager.hashWithSalt(answer.trim().lowercase(), salt)
        return computedHash == expectedHash
    }

    fun verifyRecoveryKey(key: String): Boolean {
        val stored = prefs.getString(KEY_RECOVERY_KEY, "") ?: ""
        return stored.isNotBlank() && stored.equals(key.trim().uppercase(), ignoreCase = true)
    }

    fun shouldAutoLock(): Boolean {
        if (!isPinSet) return false
        if (autoLockTimeoutSeconds == 0) return true
        val elapsed = (System.currentTimeMillis() - lastBackgroundTime) / 1000
        return elapsed >= autoLockTimeoutSeconds
    }
}
