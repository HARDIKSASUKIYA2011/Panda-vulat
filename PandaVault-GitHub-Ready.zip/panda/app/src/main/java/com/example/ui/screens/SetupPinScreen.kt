package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.localization.AppLanguage
import com.example.localization.Strings
import com.example.ui.components.PandaTopBar
import com.example.ui.components.PinKeypad
import com.example.ui.theme.BambooEmerald
import com.example.ui.theme.PandaRose
import com.example.ui.viewmodel.VaultViewModel

@Composable
fun SetupPinScreen(
    viewModel: VaultViewModel,
    isChangePin: Boolean,
    language: AppLanguage,
    onBackClick: (() -> Unit)? = null
) {
    // Steps:
    // If Change PIN: Step 0 (Old PIN) -> Step 1 (New PIN) -> Step 2 (Confirm New PIN)
    // If Setup: Step 1 (Create PIN) -> Step 2 (Confirm PIN) -> Step 3 (Security Question)
    var step by remember { mutableIntStateOf(if (isChangePin) 0 else 1) }
    var oldPin by remember { mutableStateOf("") }
    var firstPin by remember { mutableStateOf("") }
    var secondPin by remember { mutableStateOf("") }
    var securityQuestion by remember { mutableStateOf("What was your first pet's name?") }
    var securityAnswer by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            PandaTopBar(
                title = if (isChangePin) Strings.get("change_pin", language) else Strings.get("create_pin", language),
                language = language,
                onBackClick = onBackClick
            )

            if (step <= 2) {
                // Keypad input step
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            modifier = Modifier
                                .size(72.dp)
                                .clip(CircleShape)
                                .background(BambooEmerald.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.ic_panda_logo),
                                contentDescription = null,
                                modifier = Modifier.size(54.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        val titleText = when (step) {
                            0 -> Strings.get("enter_pin", language)
                            1 -> Strings.get("create_pin", language)
                            else -> Strings.get("confirm_pin", language)
                        }
                        val descText = when (step) {
                            0 -> Strings.get("enter_pin_desc", language)
                            1 -> Strings.get("create_pin_desc", language)
                            else -> Strings.get("confirm_pin_desc", language)
                        }

                        Text(
                            text = titleText,
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                        )

                        Text(
                            text = descText,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            ),
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(top = 4.dp, bottom = 8.dp)
                        )

                        if (errorMessage != null) {
                            Text(
                                text = errorMessage!!,
                                color = PandaRose,
                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                    }

                    val currentInput = when (step) {
                        0 -> oldPin
                        1 -> firstPin
                        else -> secondPin
                    }

                    PinKeypad(
                        currentPin = currentInput,
                        maxDigits = 6,
                        onPinChange = { newPin ->
                            errorMessage = null
                            when (step) {
                                0 -> {
                                    oldPin = newPin
                                    if (newPin.length >= 4) {
                                        if (viewModel.securityPrefs.verifyPin(newPin)) {
                                            step = 1
                                        } else if (newPin.length >= 6) {
                                            errorMessage = Strings.get("pin_incorrect", language)
                                            oldPin = ""
                                        }
                                    }
                                }
                                1 -> {
                                    firstPin = newPin
                                    if (newPin.length >= 4 && newPin.length == 6) {
                                        step = 2
                                    }
                                }
                                2 -> {
                                    secondPin = newPin
                                    if (newPin.length == firstPin.length) {
                                        if (newPin == firstPin) {
                                            if (isChangePin) {
                                                viewModel.changePin(oldPin, firstPin)
                                                onBackClick?.invoke()
                                            } else {
                                                step = 3
                                            }
                                        } else {
                                            errorMessage = Strings.get("pin_mismatch", language)
                                            secondPin = ""
                                        }
                                    }
                                }
                            }
                        },
                        language = language
                    )

                    if (step == 1 && firstPin.length >= 4) {
                        Button(
                            onClick = { step = 2 },
                            colors = ButtonDefaults.buttonColors(containerColor = BambooEmerald),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("setup_pin_next_button")
                        ) {
                            Text(Strings.get("confirm", language), fontWeight = FontWeight.Bold)
                        }
                    } else {
                        Spacer(modifier = Modifier.height(16.dp))
                    }
                }
            } else {
                // Step 3: Security Question Setup
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp)
                        .verticalScroll(rememberScrollState()),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = BambooEmerald.copy(alpha = 0.1f)
                        ),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Security,
                                contentDescription = null,
                                tint = BambooEmerald,
                                modifier = Modifier.size(32.dp)
                            )
                            Spacer(modifier = Modifier.size(12.dp))
                            Text(
                                text = Strings.get("recovery_warning", language),
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Text(
                        text = Strings.get("security_question", language),
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground
                        ),
                        modifier = Modifier.align(Alignment.Start)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = securityQuestion,
                        onValueChange = { securityQuestion = it },
                        label = { Text("Question") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("security_question_input")
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = Strings.get("security_answer", language),
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground
                        ),
                        modifier = Modifier.align(Alignment.Start)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = securityAnswer,
                        onValueChange = { securityAnswer = it },
                        label = { Text("Secret Answer") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("security_answer_input")
                    )

                    Spacer(modifier = Modifier.height(32.dp))

                    Button(
                        onClick = {
                            if (securityAnswer.isNotBlank()) {
                                viewModel.setupPin(firstPin, securityQuestion, securityAnswer)
                            }
                        },
                        enabled = securityAnswer.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(containerColor = BambooEmerald),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("finish_vault_setup_button")
                    ) {
                        Text(
                            text = Strings.get("save", language),
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium
                        )
                    }
                }
            }
        }
    }
}
