package com.example.service

import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.IBinder
import com.example.data.db.AppDatabase
import com.example.ui.lock.AppLockOverlayActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class AppLockService : Service() {
    private val serviceJob = Job()
    private val serviceScope = CoroutineScope(Dispatchers.Default + serviceJob)
    private var lastCheckedPackage: String? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startMonitoring()
        return START_STICKY
    }

    private fun startMonitoring() {
        serviceScope.launch {
            val database = AppDatabase.getInstance(applicationContext)
            val dao = database.vaultDao()

            while (isActive) {
                try {
                    val currentPackage = getTopPackageName()
                    if (currentPackage != null &&
                        currentPackage != packageName &&
                        currentPackage != lastCheckedPackage
                    ) {
                        // Check if unlocked recently
                        val isRecentlyUnlocked = AppLockOverlayActivity.unlockedPackage == currentPackage &&
                                (System.currentTimeMillis() - AppLockOverlayActivity.unlockTimestamp < 15_000)

                        if (!isRecentlyUnlocked) {
                            val lockedApp = dao.getLockedApp(currentPackage)
                            if (lockedApp != null && lockedApp.isLocked) {
                                lastCheckedPackage = currentPackage
                                val overlayIntent = Intent(applicationContext, AppLockOverlayActivity::class.java).apply {
                                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                                    putExtra(AppLockOverlayActivity.EXTRA_PACKAGE_NAME, currentPackage)
                                    putExtra(AppLockOverlayActivity.EXTRA_APP_NAME, lockedApp.appName)
                                }
                                startActivity(overlayIntent)
                            }
                        }
                    }

                    if (currentPackage != lastCheckedPackage && currentPackage != packageName) {
                        lastCheckedPackage = currentPackage
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
                delay(600)
            }
        }
    }

    private fun getTopPackageName(): String? {
        val usageStatsManager = getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager ?: return null
        val endTime = System.currentTimeMillis()
        val startTime = endTime - 1000 * 5 // last 5 seconds

        val usageEvents = usageStatsManager.queryEvents(startTime, endTime)
        val event = UsageEvents.Event()
        var topPackage: String? = null

        while (usageEvents.hasNextEvent()) {
            usageEvents.getNextEvent(event)
            if (event.eventType == UsageEvents.Event.ACTIVITY_RESUMED) {
                topPackage = event.packageName
            }
        }
        return topPackage
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceJob.cancel()
    }
}
