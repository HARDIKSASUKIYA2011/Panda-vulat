package com.example.data.repository

import android.content.ContentResolver
import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import com.example.data.db.VaultDao
import com.example.data.model.VaultFileType
import com.example.data.model.VaultFolder
import com.example.data.model.VaultItem
import com.example.data.model.VaultStats
import com.example.data.security.CryptoManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID

class VaultRepository(
    private val context: Context,
    private val vaultDao: VaultDao
) {
    private val vaultBaseDir: File = File(context.filesDir, "vault").apply {
        if (!exists()) mkdirs()
        // Ensure .nomedia is created at root of vault
        File(this, ".nomedia").createNewFile()
    }

    private fun getSubDir(type: VaultFileType): File {
        val dir = File(vaultBaseDir, type.name.lowercase()).apply {
            if (!exists()) mkdirs()
            File(this, ".nomedia").createNewFile()
        }
        return dir
    }

    val allActiveItems: Flow<List<VaultItem>> = vaultDao.getAllActiveItems()
    val photos: Flow<List<VaultItem>> = vaultDao.getItemsByType(VaultFileType.PHOTO.name)
    val videos: Flow<List<VaultItem>> = vaultDao.getItemsByType(VaultFileType.VIDEO.name)
    val documents: Flow<List<VaultItem>> = vaultDao.getItemsByType(VaultFileType.DOCUMENT.name)
    val otherFiles: Flow<List<VaultItem>> = vaultDao.getItemsByType(VaultFileType.OTHER.name)
    val deletedItems: Flow<List<VaultItem>> = vaultDao.getDeletedItems()
    val allFolders: Flow<List<VaultFolder>> = vaultDao.getAllFolders()

    fun getItemsByFolder(folderId: Long): Flow<List<VaultItem>> = vaultDao.getItemsByFolder(folderId)

    val statsFlow: Flow<VaultStats> = combine(
        vaultDao.getTotalActiveCount(),
        vaultDao.getCountByType(VaultFileType.PHOTO.name),
        vaultDao.getCountByType(VaultFileType.VIDEO.name),
        vaultDao.getCountByType(VaultFileType.DOCUMENT.name),
        vaultDao.getCountByType(VaultFileType.OTHER.name),
        vaultDao.getTotalSizeBytes(),
        vaultDao.getTrashCount()
    ) { args: Array<Any?> ->
        VaultStats(
            totalItems = args[0] as? Int ?: 0,
            photoCount = args[1] as? Int ?: 0,
            videoCount = args[2] as? Int ?: 0,
            documentCount = args[3] as? Int ?: 0,
            fileCount = args[4] as? Int ?: 0,
            totalSizeBytes = args[5] as? Long ?: 0L,
            trashCount = args[6] as? Int ?: 0
        )
    }

    suspend fun importFile(uri: Uri, targetFolderId: Long? = null): Result<VaultItem> = withContext(Dispatchers.IO) {
        try {
            val contentResolver = context.contentResolver
            val (displayName, size) = queryFileInfo(contentResolver, uri)
            val mimeType = contentResolver.getType(uri) ?: getMimeTypeFromFileName(displayName)
            val fileType = determineFileType(mimeType, displayName)

            val folderId = targetFolderId ?: getDefaultFolderId(fileType)
            val targetDir = getSubDir(fileType)
            val encryptedFileName = "enc_${UUID.randomUUID().toString().take(12)}.pve"
            val destinationFile = File(targetDir, encryptedFileName)

            val stream = contentResolver.openInputStream(uri)
                ?: return@withContext Result.failure(Exception("Cannot open input stream for $uri"))

            val success = stream.use { input ->
                CryptoManager.encryptStreamToFile(input, destinationFile)
            }

            if (!success) {
                return@withContext Result.failure(Exception("Encryption failed for $displayName"))
            }

            val finalSize = if (size > 0) size else destinationFile.length()

            val vaultItem = VaultItem(
                fileName = displayName,
                originalPath = uri.toString(),
                vaultPath = destinationFile.absolutePath,
                fileType = fileType.name,
                mimeType = mimeType,
                fileSize = finalSize,
                folderId = folderId,
                isDeleted = false,
                isEncrypted = true
            )

            val id = vaultDao.insertItem(vaultItem)
            Result.success(vaultItem.copy(id = id))
        } catch (e: Exception) {
            e.printStackTrace()
            Result.failure(e)
        }
    }

    suspend fun getItemById(id: Long): VaultItem? = withContext(Dispatchers.IO) {
        vaultDao.getItemById(id)
    }

    suspend fun decryptToTempFile(item: VaultItem): File? = withContext(Dispatchers.IO) {
        try {
            val encFile = File(item.vaultPath)
            if (!encFile.exists()) return@withContext null
            val tempDir = File(context.cacheDir, "temp_view").apply {
                if (!exists()) mkdirs()
                File(this, ".nomedia").createNewFile()
            }
            // Keep original extension so players and viewers can recognize it
            val ext = item.fileName.substringAfterLast('.', "")
            val suffix = if (ext.isNotEmpty()) ".$ext" else ""
            val tempFile = File(tempDir, "view_${item.id}_${System.currentTimeMillis()}$suffix")
            tempFile.deleteOnExit()

            val success = CryptoManager.decryptFileToTempFile(encFile, tempFile)
            if (success) tempFile else null
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    suspend fun decryptToBytes(item: VaultItem): ByteArray? = withContext(Dispatchers.IO) {
        val encFile = File(item.vaultPath)
        CryptoManager.decryptFileToBytes(encFile)
    }

    suspend fun restoreItemToStream(item: VaultItem, outputStream: OutputStream): Boolean = withContext(Dispatchers.IO) {
        try {
            val encFile = File(item.vaultPath)
            if (!encFile.exists()) return@withContext false
            CryptoManager.decryptFileToStream(encFile, outputStream)
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    suspend fun softDelete(id: Long) = withContext(Dispatchers.IO) {
        vaultDao.softDeleteItem(id)
    }

    suspend fun restoreFromTrash(id: Long) = withContext(Dispatchers.IO) {
        vaultDao.restoreItem(id)
    }

    suspend fun permanentlyDelete(item: VaultItem) = withContext(Dispatchers.IO) {
        try {
            val file = File(item.vaultPath)
            if (file.exists()) {
                file.delete()
            }
            vaultDao.permanentlyDeleteItem(item.id)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    suspend fun emptyTrash() = withContext(Dispatchers.IO) {
        try {
            // Remove physical files
            val trashDir = File(vaultBaseDir, "trash")
            trashDir.deleteRecursively()
            vaultDao.emptyTrash()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    suspend fun renameItem(id: Long, newName: String) = withContext(Dispatchers.IO) {
        vaultDao.renameItem(id, newName.trim())
    }

    suspend fun moveItemToFolder(id: Long, folderId: Long) = withContext(Dispatchers.IO) {
        vaultDao.moveItemToFolder(id, folderId)
    }

    suspend fun createFolder(name: String, type: String = "GENERAL"): Long = withContext(Dispatchers.IO) {
        vaultDao.insertFolder(
            VaultFolder(
                name = name.trim(),
                type = type,
                iconName = "folder",
                isSystem = false
            )
        )
    }

    suspend fun deleteFolder(folder: VaultFolder) = withContext(Dispatchers.IO) {
        if (!folder.isSystem) {
            vaultDao.deleteFolder(folder)
        }
    }

    private fun getDefaultFolderId(type: VaultFileType): Long {
        return when (type) {
            VaultFileType.PHOTO -> 1L
            VaultFileType.VIDEO -> 2L
            VaultFileType.DOCUMENT -> 3L
            VaultFileType.OTHER -> 5L
        }
    }

    private fun determineFileType(mimeType: String, fileName: String): VaultFileType {
        val lowerMime = mimeType.lowercase()
        val ext = fileName.substringAfterLast('.', "").lowercase()

        return when {
            lowerMime.startsWith("image/") || ext in listOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic") ->
                VaultFileType.PHOTO
            lowerMime.startsWith("video/") || ext in listOf("mp4", "mkv", "mov", "avi", "3gp", "webm", "flv") ->
                VaultFileType.VIDEO
            lowerMime.startsWith("text/") || lowerMime.contains("pdf") || lowerMime.contains("word") ||
                    lowerMime.contains("officedocument") || lowerMime.contains("sheet") ||
                    ext in listOf("pdf", "doc", "docx", "txt", "xlsx", "xls", "ppt", "pptx", "csv") ->
                VaultFileType.DOCUMENT
            else ->
                VaultFileType.OTHER
        }
    }

    private fun queryFileInfo(contentResolver: ContentResolver, uri: Uri): Pair<String, Long> {
        var name = "vault_file_${System.currentTimeMillis()}"
        var size = 0L
        try {
            contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (cursor.moveToFirst()) {
                    if (nameIndex != -1) name = cursor.getString(nameIndex) ?: name
                    if (sizeIndex != -1) size = cursor.getLong(sizeIndex)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return Pair(name, size)
    }

    private fun getMimeTypeFromFileName(fileName: String): String {
        val extension = fileName.substringAfterLast('.', "")
        return if (extension.isNotEmpty()) {
            MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension.lowercase()) ?: "application/octet-stream"
        } else {
            "application/octet-stream"
        }
    }
}
