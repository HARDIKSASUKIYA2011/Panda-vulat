package com.example.ui.screens

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DriveFileMove
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.VaultItem
import com.example.localization.AppLanguage
import com.example.localization.Strings
import com.example.ui.components.ConfirmDeleteDialog
import com.example.ui.components.CreateFolderDialog
import com.example.ui.components.FolderSelectDialog
import com.example.ui.components.RenameDialog
import com.example.ui.theme.BambooEmerald
import com.example.ui.theme.PandaRose
import com.example.ui.viewmodel.VaultViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PhotoViewerScreen(
    viewModel: VaultViewModel,
    itemId: Long,
    language: AppLanguage,
    onBackClick: () -> Unit
) {
    val context = LocalContext.current
    val folders by viewModel.folders.collectAsState()
    var item by remember { mutableStateOf<VaultItem?>(null) }
    var bitmap by remember { mutableStateOf<Bitmap?>(null) }
    var isLoading by remember { mutableStateOf(true) }

    var showRenameDialog by remember { mutableStateOf(false) }
    var showFolderDialog by remember { mutableStateOf(false) }
    var showCreateFolderDialog by remember { mutableStateOf(false) }
    var showDeleteConfirmDialog by remember { mutableStateOf(false) }

    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }

    val transformState = rememberTransformableState { zoomChange, offsetChange, _ ->
        scale = (scale * zoomChange).coerceIn(1f, 5f)
        offset = if (scale > 1f) offset + offsetChange else Offset.Zero
    }

    LaunchedEffect(itemId) {
        withContext(Dispatchers.IO) {
            val vaultItem = viewModel.repository.getItemById(itemId)
            item = vaultItem
            if (vaultItem != null) {
                val bytes = viewModel.repository.decryptToBytes(vaultItem)
                if (bytes != null) {
                    val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                    withContext(Dispatchers.Main) {
                        bitmap = bmp
                        isLoading = false
                    }
                } else {
                    withContext(Dispatchers.Main) { isLoading = false }
                }
            } else {
                withContext(Dispatchers.Main) { isLoading = false }
            }
        }
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color.Black
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            TopAppBar(
                title = {
                    Text(
                        text = item?.fileName ?: Strings.get("nav_photos", language),
                        style = MaterialTheme.typography.titleMedium.copy(color = Color.White),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Black.copy(alpha = 0.8f))
            )

            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .background(Color.Black),
                contentAlignment = Alignment.Center
            ) {
                if (isLoading) {
                    CircularProgressIndicator(color = BambooEmerald)
                } else if (bitmap != null) {
                    Image(
                        bitmap = bitmap!!.asImageBitmap(),
                        contentDescription = item?.fileName,
                        contentScale = ContentScale.Fit,
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer(
                                scaleX = scale,
                                scaleY = scale,
                                translationX = offset.x,
                                translationY = offset.y
                            )
                            .transformable(state = transformState)
                    )
                } else {
                    Text(
                        text = "Unable to decrypt image",
                        color = Color.White.copy(alpha = 0.7f)
                    )
                }
            }

            // Bottom Actions Bar
            item?.let { currentItem ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.Black.copy(alpha = 0.8f))
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = { showRenameDialog = true },
                        modifier = Modifier.testTag("photo_viewer_rename")
                    ) {
                        Icon(imageVector = Icons.Default.Edit, contentDescription = "Rename", tint = Color.White)
                    }

                    IconButton(
                        onClick = { showFolderDialog = true },
                        modifier = Modifier.testTag("photo_viewer_move")
                    ) {
                        Icon(imageVector = Icons.Default.DriveFileMove, contentDescription = "Move", tint = Color.White)
                    }

                    IconButton(
                        onClick = { viewModel.restoreItemToDownloads(currentItem, context) },
                        modifier = Modifier.testTag("photo_viewer_restore")
                    ) {
                        Icon(imageVector = Icons.Default.Restore, contentDescription = "Restore", tint = BambooEmerald)
                    }

                    IconButton(
                        onClick = { showDeleteConfirmDialog = true },
                        modifier = Modifier.testTag("photo_viewer_delete")
                    ) {
                        Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = PandaRose)
                    }
                }
            }
        }
    }

    item?.let { currentItem ->
        if (showRenameDialog) {
            RenameDialog(
                initialName = currentItem.fileName,
                language = language,
                onDismiss = { showRenameDialog = false },
                onConfirm = { newName ->
                    viewModel.renameItem(currentItem.id, newName)
                    item = currentItem.copy(fileName = newName)
                    showRenameDialog = false
                }
            )
        }

        if (showFolderDialog) {
            FolderSelectDialog(
                folders = folders,
                language = language,
                onDismiss = { showFolderDialog = false },
                onSelectFolder = { folderId ->
                    viewModel.moveItemToFolder(currentItem.id, folderId)
                    showFolderDialog = false
                },
                onCreateFolder = {
                    showFolderDialog = false
                    showCreateFolderDialog = true
                }
            )
        }

        if (showCreateFolderDialog) {
            CreateFolderDialog(
                language = language,
                onDismiss = { showCreateFolderDialog = false },
                onConfirm = { folderName ->
                    viewModel.createFolder(folderName, "PHOTO")
                    showCreateFolderDialog = false
                }
            )
        }

        if (showDeleteConfirmDialog) {
            ConfirmDeleteDialog(
                title = Strings.get("delete", language),
                message = Strings.get("file_deleted", language),
                language = language,
                onDismiss = { showDeleteConfirmDialog = false },
                onConfirm = {
                    viewModel.softDelete(currentItem.id)
                    showDeleteConfirmDialog = false
                    onBackClick()
                }
            )
        }
    }
}
