package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = BambooEmerald,
    onPrimary = Color(0xFF022C22),
    primaryContainer = BambooEmeraldDark,
    onPrimaryContainer = BambooMint,
    secondary = BambooMint,
    onSecondary = Color(0xFF064E3B),
    secondaryContainer = Color(0xFF1E293B),
    onSecondaryContainer = Color(0xFFE2E8F0),
    tertiary = PandaGold,
    onTertiary = Color(0xFF451A03),
    background = PandaDarkBackground,
    onBackground = TextPrimaryDark,
    surface = PandaDarkSurface,
    onSurface = TextPrimaryDark,
    surfaceVariant = PandaDarkCard,
    onSurfaceVariant = TextSecondaryDark,
    outline = PandaDarkBorder,
    error = PandaRose
)

private val LightColorScheme = lightColorScheme(
    primary = PandaLightPrimary,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD1FAE5),
    onPrimaryContainer = Color(0xFF065F46),
    secondary = Color(0xFF0D9488),
    onSecondary = Color.White,
    secondaryContainer = PandaLightCard,
    onSecondaryContainer = Color(0xFF1E293B),
    tertiary = PandaGold,
    onTertiary = Color.White,
    background = PandaLightBackground,
    onBackground = TextPrimaryLight,
    surface = PandaLightSurface,
    onSurface = TextPrimaryLight,
    surfaceVariant = PandaLightCard,
    onSurfaceVariant = TextSecondaryLight,
    outline = PandaLightBorder,
    error = PandaRose
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Set to false to preserve brand panda emerald/dark identity
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
