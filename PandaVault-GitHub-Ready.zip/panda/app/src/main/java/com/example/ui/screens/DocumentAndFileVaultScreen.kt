package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.VaultItem
import com.example.localization.AppLanguage
import com.example.localization.Strings
import com.example.ui.components.ConfirmDeleteDialog
import com.example.ui.components.CreateFolderDialog
import com.example.ui.components.FolderSelectDialog
import com.example.ui.components.MultiSelectActionBar
import com.example.ui.components.PandaTopBar
import com.example.ui.components.RenameDialog
import com.example.ui.theme.BambooEmerald
import com.example.ui.theme.PandaGold
import com.example.ui.theme.PandaPurple
import com.example.ui.theme.PandaRose
import com.example.ui.viewmodel.VaultViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DocumentAndFileVaultScreen(
    viewModel: VaultViewModel,
    isDocumentsOnly: Boolean,
    folderId: Long?,
    language: AppLanguage,
    onBackClick: () -> Unit,
    onItemClick: (Long) -> Unit
) {
    val context = LocalContext.current
    val itemsFlow = if (isDocumentsOnly) viewModel.documents else viewModel.allFiles
    val allItems by itemsFlow.collectAsState()
    val folders by viewModel.folders.collectAsState()
    val selectedIds by viewModel.selectedItemIds.collectAsState()

    val displayItems = if (folderId != null) {
        allItems.filter { it.folderId == folderId }
    } else {
        allItems
    }

    var itemToRename by remember { mutableStateOf<VaultItem?>(null) }
    var itemToMove by remember { mutableStateOf<VaultItem?>(null) }
    var itemToDelete by remember { mutableStateOf<VaultItem?>(null) }
    var showFolderSelectDialog by remember { mutableStateOf(false) }
    var showCreateFolderDialog by remember { mutableStateOf(false) }
    var showMultiDeleteConfirm by remember { mutableStateOf(false) }

    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isNotEmpty()) {
            viewModel.importUris(uris, folderId)
        }
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            Column(modifier = Modifier.fillMaxSize()) {
                PandaTopBar(
                    title = if (isDocumentsOnly) Strings.get("nav_documents", language) else Strings.get("nav_files", language),
                    language = language,
                    onBackClick = onBackClick
                )

                if (selectedIds.isNotEmpty()) {
                    MultiSelectActionBar(
                        selectedCount = selectedIds.size,
                        language = language,
                        onClearSelection = { viewModel.clearSelection() },
                        onSelectAll = { viewModel.selectAll(displayItems.map { it.id }) },
                        onMoveSelected = { showFolderSelectDialog = true },
                        onRestoreSelected = { viewModel.restoreSelectedToDownloads(context) },
                        onDeleteSelected = { showMultiDeleteConfirm = true }
                    )
                }

                if (displayItems.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = if (isDocumentsOnly) Icons.Default.Description else Icons.Default.FolderZip,
                                contentDescription = null,
                                tint = if (isDocumentsOnly) PandaGold.copy(alpha = 0.5f) else PandaPurple.copy(alpha = 0.5f),
                                modifier = Modifier.size(72.dp)
                            )
                            Text(
                                text = if (isDocumentsOnly) Strings.get("empty_docs_title", language) else Strings.get("empty_files_title", language),
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                modifier = Modifier.padding(top = 16.dp)
                            )
                            Text(
                                text = if (isDocumentsOnly) Strings.get("empty_docs_desc", language) else Strings.get("empty_files_desc", language),
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                ),
                                modifier = Modifier.padding(top = 8.dp)
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(displayItems, key = { it.id }) { item ->
                            val isSelected = selectedIds.contains(item.id)
                            FileListItem(
                                item = item,
                                isSelected = isSelected,
                                language = language,
                                onClick = {
                                    if (selectedIds.isNotEmpty()) {
                                        viewModel.toggleSelection(item.id)
                                    } else {
                                        onItemClick(item.id)
                                    }
                                },
                                onLongClick = { viewModel.toggleSelection(item.id) },
                                onRename = { itemToRename = item },
                                onMove = { itemToMove = item },
                                onRestore = { viewModel.restoreItemToDownloads(item, context) },
                                onDelete = { itemToDelete = item }
                            )
                        }
                    }
                }
            }

            // Import FAB
            FloatingActionButton(
                onClick = {
                    filePickerLauncher.launch(
                        if (isDocumentsOnly) {
                            arrayOf(
                                "application/pdf",
                                "application/msword",
                                "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                                "application/vnd.ms-excel",
                                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                "text/plain",
                                "text/*"
                            )
                        } else {
                            arrayOf("*/*")
                        }
                    )
                },
                containerColor = if (isDocumentsOnly) PandaGold else PandaPurple,
                contentColor = Color.White,
                shape = CircleShape,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(24.dp)
                    .testTag("import_files_fab")
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Import",
                    modifier = Modifier.size(28.dp)
                )
            }
        }
    }

    itemToRename?.let { item ->
        RenameDialog(
            initialName = item.fileName,
            language = language,
            onDismiss = { itemToRename = null },
            onConfirm = { newName ->
                viewModel.renameItem(item.id, newName)
                itemToRename = null
            }
        )
    }

    itemToMove?.let { item ->
        FolderSelectDialog(
            folders = folders,
            language = language,
            onDismiss = { itemToMove = null },
            onSelectFolder = { targetFolderId ->
                viewModel.moveItemToFolder(item.id, targetFolderId)
                itemToMove = null
            },
            onCreateFolder = {
                itemToMove = null
                showCreateFolderDialog = true
            }
        )
    }

    itemToDelete?.let { item ->
        ConfirmDeleteDialog(
            title = Strings.get("delete", language),
            message = Strings.get("file_deleted", language),
            language = language,
            onDismiss = { itemToDelete = null },
            onConfirm = {
                viewModel.softDelete(item.id)
                itemToDelete = null
            }
        )
    }

    if (showFolderSelectDialog) {
        FolderSelectDialog(
            folders = folders,
            language = language,
            onDismiss = { showFolderSelectDialog = false },
            onSelectFolder = { targetFolderId ->
                viewModel.moveSelectedToFolder(targetFolderId)
                showFolderSelectDialog = false
            },
            onCreateFolder = {
                showFolderSelectDialog = false
                showCreateFolderDialog = true
            }
        )
    }

    if (showCreateFolderDialog) {
        CreateFolderDialog(
            language = language,
            onDismiss = { showCreateFolderDialog = false },
            onConfirm = { folderName ->
                viewModel.createFolder(folderName, if (isDocumentsOnly) "DOCUMENT" else "GENERAL")
                showCreateFolderDialog = false
            }
        )
    }

    if (showMultiDeleteConfirm) {
        ConfirmDeleteDialog(
            title = Strings.get("delete", language),
            message = Strings.get("file_deleted", language),
            language = language,
            onDismiss = { showMultiDeleteConfirm = false },
            onConfirm = {
                viewModel.softDeleteSelected()
                showMultiDeleteConfirm = false
            }
        )
    }
}

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
fun FileListItem(
    item: VaultItem,
    isSelected: Boolean,
    language: AppLanguage,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onRename: () -> Unit,
    onMove: () -> Unit,
    onRestore: () -> Unit,
    onDelete: () -> Unit
) {
    var showMenu by remember { mutableStateOf(false) }
    val (icon, badgeColor) = getFileTypeIconAndColor(item.fileName, item.mimeType)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .border(
                width = if (isSelected) 2.dp else 0.dp,
                color = if (isSelected) BambooEmerald else Color.Transparent,
                shape = RoundedCornerShape(16.dp)
            )
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .testTag("file_item_${item.id}"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(badgeColor.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                if (isSelected) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Selected",
                        tint = BambooEmerald,
                        modifier = Modifier.size(30.dp)
                    )
                } else {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = badgeColor,
                        modifier = Modifier.size(30.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.fileName,
                    style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.SemiBold),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row {
                    Text(
                        text = formatFileSize(item.fileSize),
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )
                    Text(
                        text = " • " + SimpleDateFormat("MMM d, yyyy", Locale.getDefault()).format(Date(item.createdAt)),
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )
                }
            }

            Box {
                IconButton(onClick = { showMenu = true }) {
                    Icon(
                        imageVector = Icons.Default.MoreVert,
                        contentDescription = "Options"
                    )
                }

                DropdownMenu(
                    expanded = showMenu,
                    onDismissRequest = { showMenu = false }
                ) {
                    DropdownMenuItem(
                        text = { Text(Strings.get("rename", language)) },
                        onClick = {
                            showMenu = false
                            onRename()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text(Strings.get("move", language)) },
                        onClick = {
                            showMenu = false
                            onMove()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text(Strings.get("restore", language)) },
                        onClick = {
                            showMenu = false
                            onRestore()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text(Strings.get("delete", language)) },
                        onClick = {
                            showMenu = false
                            onDelete()
                        }
                    )
                }
            }
        }
    }
}

fun getFileTypeIconAndColor(fileName: String, mimeType: String): Pair<ImageVector, Color> {
    val ext = fileName.substringAfterLast('.', "").lowercase()
    return when {
        ext == "pdf" || mimeType.contains("pdf") -> Pair(Icons.Default.PictureAsPdf, Color(0xFFEF4444))
        ext in listOf("doc", "docx") || mimeType.contains("word") -> Pair(Icons.Default.Description, Color(0xFF3B82F6))
        ext in listOf("xls", "xlsx", "csv") || mimeType.contains("sheet") -> Pair(Icons.Default.TableChart, Color(0xFF10B981))
        ext in listOf("zip", "rar", "7z", "tar", "gz") -> Pair(Icons.Default.FolderZip, Color(0xFFF59E0B))
        ext in listOf("txt", "md", "log", "json", "xml") -> Pair(Icons.Default.Code, Color(0xFF8B5CF6))
        ext in listOf("mp3", "wav", "aac", "ogg", "flac") || mimeType.startsWith("audio/") -> Pair(Icons.Default.Audiotrack, Color(0xFFEC4899))
        else -> Pair(Icons.Default.InsertDriveFile, Color(0xFF64748B))
    }
}
