package com.example.localization

enum class AppLanguage(val code: String, val displayName: String, val nativeName: String) {
    ENGLISH("en", "English", "English"),
    GUJARATI("gu", "Gujarati", "ગુજરાતી")
}

object Strings {
    private val translations = mapOf(
        "app_title" to Pair("Panda Vault", "પાન્ડા વૉલ્ટ"),
        "app_subtitle" to Pair("App Hider & Secure Locker", "એપ હાઇડર અને સુરક્ષિત લૉકર"),
        "enter_pin" to Pair("Enter Security PIN", "સુરક્ષા પિન દાખલ કરો"),
        "enter_pin_desc" to Pair("Enter your 4-6 digit PIN to access Panda Vault", "પાન્ડા વૉલ્ટ ઍક્સેસ કરવા માટે તમારો 4-6 અંકનો પિન દાખલ કરો"),
        "create_pin" to Pair("Create Vault PIN", "વૉલ્ટ પિન બનાવો"),
        "create_pin_desc" to Pair("Choose a strong PIN to protect your private vault", "તમારા ખાનગી વૉલ્ટનું રક્ષણ કરવા માટે મજબૂત પિન પસંદ કરો"),
        "confirm_pin" to Pair("Confirm Your PIN", "તમારા પિનની પુષ્ટિ કરો"),
        "confirm_pin_desc" to Pair("Re-enter the same PIN to confirm", "ખાતરી કરવા માટે સમાન પિન ફરીથી દાખલ કરો"),
        "pin_mismatch" to Pair("PINs do not match. Try again.", "પિન મેળ ખાતા નથી. ફરી પ્રયાસ કરો."),
        "pin_incorrect" to Pair("Incorrect PIN. Please try again.", "ખોટો પિન. કૃપા કરીને ફરી પ્રયાસ કરો."),
        "biometric_prompt_title" to Pair("Unlock Panda Vault", "પાન્ડા વૉલ્ટ અનલૉક કરો"),
        "biometric_prompt_desc" to Pair("Verify your fingerprint or face to unlock", "અનલૉક કરવા માટે તમારી ફિંગરપ્રિન્ટ અથવા ફેસ ચકાસો"),
        "biometric_unlock" to Pair("Unlock with Biometrics", "બાયોમેટ્રિક દ્વારા અનલૉક કરો"),
        "forgot_pin" to Pair("Forgot PIN?", "પિન ભૂલી ગયા છો?"),
        "recovery_title" to Pair("PIN Recovery", "પિન પુનઃપ્રાપ્તિ"),
        "recovery_warning" to Pair("Zero Backdoor Guarantee: Panda Vault uses end-to-end device encryption. If recovery answers are lost, data cannot be decrypted by anyone.", "ઝીરો બેકડૂર ગેરંટી: પાન્ડા વૉલ્ટ ઉપકરણ એન્ક્રિપ્શનનો ઉપયોગ કરે છે. જો પુનઃપ્રાપ્તિ પદ્ધતિ ખોવાઈ જાય, તો ડેટા ક્યારેય ડિક્રિપ્ટ થઈ શકશે નહીં."),
        "security_question" to Pair("Security Question", "સુરક્ષા પ્રશ્ન"),
        "security_answer" to Pair("Your Secret Answer", "તમારો ગુપ્ત જવાબ"),
        "reset_pin" to Pair("Reset PIN", "પિન ફરીથી સેટ કરો"),
        "cancel" to Pair("Cancel", "રદ કરો"),
        "confirm" to Pair("Confirm", "પુષ્ટિ કરો"),
        "save" to Pair("Save", "સાચવો"),
        "delete" to Pair("Delete", "કાઢી નાખો"),
        "rename" to Pair("Rename", "નામ બદલો"),
        "restore" to Pair("Restore to Device", "ઉપકરણમાં પુનઃસ્થાપિત કરો"),
        "move" to Pair("Move to Folder", "ફોલ્ડરમાં ખસેડો"),
        "select_all" to Pair("Select All", "બધા પસંદ કરો"),
        "clear_selection" to Pair("Clear", "ચોખ્ખું કરો"),
        "selected" to Pair("Selected", "પસંદ કરેલ"),

        // Dashboard & Categories
        "nav_photos" to Pair("Photos", "ફોટા"),
        "nav_videos" to Pair("Videos", "વિડિઓ"),
        "nav_documents" to Pair("Documents", "દસ્તાવેજો"),
        "nav_files" to Pair("Files", "ફાઇલો"),
        "nav_app_lock" to Pair("App Lock", "એપ લૉક"),
        "nav_settings" to Pair("Settings", "સેટિંગ્સ"),
        "nav_folders" to Pair("Folders", "ફોલ્ડર્સ"),
        "nav_trash" to Pair("Recycle Bin", "કચરાપેટી"),

        "items_count" to Pair("items protected", "વસ્તુઓ સુરક્ષિત"),
        "quick_import" to Pair("Import Files", "ફાઇલો આયાત કરો"),
        "empty_photos_title" to Pair("No Hidden Photos", "કોઈ છુપાયેલ ફોટા નથી"),
        "empty_photos_desc" to Pair("Tap '+' to safely import and encrypt photos. They will be hidden from device gallery.", "સુરક્ષિત રીતે ફોટા આયાત કરવા '+' ટેપ કરો. તે ગેલેરીમાંથી છુપાઈ જશે."),
        "empty_videos_title" to Pair("No Hidden Videos", "કોઈ છુપાયેલ વિડિઓ નથી"),
        "empty_videos_desc" to Pair("Safely store sensitive video recordings with in-app playback.", "ઇન-એપ પ્લેબેક સાથે સંવેદનશીલ વિડિઓઝ સુરક્ષિત રીતે સંગ્રહિત કરો."),
        "empty_docs_title" to Pair("No Protected Documents", "કોઈ સુરક્ષિત દસ્તાવેજો નથી"),
        "empty_docs_desc" to Pair("Import PDF, Word, Excel, and text files securely.", "પીડીએફ, વર્ડ, એક્સેલ અને ટેક્સ્ટ ફાઇલો સુરક્ષિત રીતે લાવો."),
        "empty_files_title" to Pair("No Vault Files", "કોઈ વૉલ્ટ ફાઇલો નથી"),
        "empty_files_desc" to Pair("Store ZIP, audio, or any custom confidential files.", "ઝીપ, ઑડિઓ અથવા કોઈપણ ગોપનીય ફાઇલો સંગ્રહિત કરો."),
        "empty_trash_title" to Pair("Recycle Bin is Empty", "કચરાપેટી ખાલી છે"),
        "empty_trash_desc" to Pair("Deleted vault items stay here until permanently purged.", "કાઢી નાખેલી વસ્તુઓ કાયમ માટે કાઢી ન નાખવામાં આવે ત્યાં સુધી અહીં રહે છે."),

        // App Lock
        "app_lock_title" to Pair("App Locker", "એપ લૉકર"),
        "app_lock_subtitle" to Pair("Protect installed apps with your Panda PIN", "તમારા પાન્ડા પિન વડે ઇન્સ્ટોલ કરેલ એપ્સનું રક્ષણ કરો"),
        "search_apps" to Pair("Search installed apps...", "ઇન્સ્ટોલ કરેલી એપ્લિકેશન શોધો..."),
        "locked_apps_count" to Pair("apps locked", "એપ્સ લૉક કરેલ છે"),
        "usage_permission_title" to Pair("Usage Access Required", "ઉપયોગ ઍક્સેસ જરૂરી છે"),
        "usage_permission_desc" to Pair("Android requires 'Usage Access' permission so Panda Vault can detect when a locked app is launched.", "Android ને 'વપરાશ ઍક્સેસ' પરવાનગીની જરૂર છે જેથી લૉક કરેલ એપ ક્યારે ખૂલે છે તે જાણી શકાય."),
        "overlay_permission_title" to Pair("Display Over Apps Required", "અન્ય એપ્સ પર પ્રદર્શિત કરો જરૂરી"),
        "overlay_permission_desc" to Pair("Requires 'Display Over Other Apps' to show the secure PIN screen immediately.", "તરત જ સુરક્ષિત પિન સ્ક્રીન બતાવવા માટે 'અન્ય એપ્લિકેશનો પર પ્રદર્શિત કરો' પરવાનગી જરૂરી છે."),
        "grant_permission" to Pair("Grant Permission", "પરવાનગી આપો"),
        "permission_granted" to Pair("Active & Granted", "સક્રિય અને માન્ય"),
        "android_security_notice_title" to Pair("Android Architecture Transparency", "Android સિસ્ટમ પારદર્શિતા નોટિસ"),
        "android_security_notice_desc" to Pair("Security Note: Non-root Android apps cannot physically remove third-party app icons from system launchers. Instead, Panda Vault uses official Android Usage Access and Overlay APIs to lock and block unauthorized opening instantly.", "સુરક્ષા નોંધ: નોન-રૂટ એન્ડ્રોઇડ એપ્સ સિસ્ટમ લૉન્ચરમાંથી તૃતીય-પક્ષ એપ્સના ચિહ્નોને ભૌતિક રીતે દૂર કરી શકતી નથી. તેના બદલે, પાન્ડા વૉલ્ટ અનધિકૃત ઍક્સેસને તરત જ લૉક કરવા સત્તાવાર Android API નો ઉપયોગ કરે છે."),

        // Settings
        "settings_security" to Pair("Security & Access", "સુરક્ષા અને ઍક્સેસ"),
        "change_pin" to Pair("Change Master PIN", "મુખ્ય પિન બદલો"),
        "change_pin_desc" to Pair("Update your vault unlock code", "તમારો વૉલ્ટ અનલૉક કોડ અપડેટ કરો"),
        "biometric_auth_switch" to Pair("Biometric Unlock", "બાયોમેટ્રિક અનલૉક"),
        "biometric_auth_desc" to Pair("Use fingerprint / face recognition", "ફિંગરપ્રિન્ટ / ફેસ અનલૉકનો ઉપયોગ કરો"),
        "autolock_timeout" to Pair("Auto-Lock Timeout", "સ્વતઃ લૉક સમય મર્યાદા"),
        "autolock_desc" to Pair("Lock automatically when app goes to background", "જ્યારે એપ બેકગ્રાઉન્ડમાં જાય ત્યારે આપમેળે લૉક કરો"),
        "flag_secure_title" to Pair("Prevent Screenshots & Previews", "સ્ક્રીનશૉટ્સ અને પ્રીવ્યૂ અટકાવો"),
        "flag_secure_desc" to Pair("Block screenshots and task switcher previews (FLAG_SECURE)", "સ્ક્રીનશૉટ્સ અને ટાસ્ક સ્વિચર પ્રીવ્યૂ બ્લૉક કરો"),
        "language_title" to Pair("Language / ભાષા", "ભાષા / Language"),
        "theme_title" to Pair("Theme Mode", "થીમ મોડ"),
        "theme_system" to Pair("System Default", "સિસ્ટમ ડિફૉલ્ટ"),
        "theme_dark" to Pair("Dark Bamboo", "ડાર્ક વાંસ મોડ"),
        "theme_light" to Pair("Light Jade", "લાઇટ જેડ મોડ"),
        "vault_storage" to Pair("Storage & Encryption", "સંગ્રહ અને એન્ક્રિપ્શન"),
        "vault_location" to Pair("Vault Storage Path", "વૉલ્ટ સ્ટોરેજ સ્થાન"),
        "vault_internal_desc" to Pair("Private sandbox with Android Keystore AES-256 GCM", "Android Keystore AES-256 GCM સાથે ખાનગી સેન્ડબૉક્સ"),
        "export_backup" to Pair("Export Encrypted Backup", "એન્ક્રિપ્ટેડ બેકઅપ નિકાસ કરો"),
        "import_backup" to Pair("Import Encrypted Backup", "એન્ક્રિપ્ટેડ બેકઅપ આયાત કરો"),
        "purge_trash" to Pair("Empty Recycle Bin", "કચરાપેટી ખાલી કરો"),
        "about_panda_vault" to Pair("About Panda Vault", "પાન્ડા વૉલ્ટ વિશે"),
        "offline_pledge_title" to Pair("100% Offline & Private Pledge", "૧૦૦% ઑફલાઇન અને ખાનગી વચન"),
        "offline_pledge_desc" to Pair("Panda Vault operates completely on your local device. Your photos, videos, and files are never transmitted to any external server.", "પાન્ડા વૉલ્ટ સંપૂર્ણપણે તમારા ઉપકરણ પર કાર્ય કરે છે. તમારી ફાઇલો ક્યારેય કોઈ સર્વર પર મોકલવામાં આવતી નથી."),
        "version_info" to Pair("Version 1.0.0 (Encrypted Build)", "સંસ્કરણ ૧.૦.૦ (સુરક્ષિત બિલ્ડ)"),

        // Dialogs & Actions
        "new_folder" to Pair("New Folder", "નવું ફોલ્ડર"),
        "folder_name" to Pair("Folder Name", "ફોલ્ડરનું નામ"),
        "create" to Pair("Create", "બનાવો"),
        "move_to" to Pair("Move to...", "આમાં ખસેડો..."),
        "file_renamed" to Pair("Item renamed successfully", "વસ્તુનું નામ સફળતાપૂર્વક બદલાયું"),
        "file_deleted" to Pair("Moved to Recycle Bin", "કચરાપેટીમાં ખસેડવામાં આવ્યું"),
        "file_restored" to Pair("Restored successfully", "સફળતાપૂર્વક પુનઃસ્થાપિત થયું"),
        "permanent_delete" to Pair("Delete Permanently", "કાયમ માટે કાઢી નાખો"),
        "permanent_delete_confirm" to Pair("Are you sure? This item cannot be recovered once deleted.", "શું તમને ખાતરી છે? આ વસ્તુ કાયમ માટે નષ્ટ થઈ જશે."),
        "import_success" to Pair("Imported and encrypted securely", "સુરક્ષિત રીતે આયાત અને એન્ક્રિપ્ટ થયેલ"),
        "video_player_title" to Pair("Secure Video Player", "સુરક્ષિત વિડિઓ પ્લેયર"),
        "doc_viewer_title" to Pair("Secure Document Viewer", "સુરક્ષિત દસ્તાવેજ દર્શક"),
        "open_external" to Pair("Open in System Viewer", "સિસ્ટમ વ્યુઅરમાં ખોલો"),
        "loading" to Pair("Loading...", "લોડ થઈ રહ્યું છે..."),
        "success" to Pair("Success", "સફળતા"),
        "error" to Pair("Error", "ભૂલ")
    )

    fun get(key: String, language: AppLanguage): String {
        val pair = translations[key] ?: return key
        return if (language == AppLanguage.GUJARATI) pair.second else pair.first
    }
}
