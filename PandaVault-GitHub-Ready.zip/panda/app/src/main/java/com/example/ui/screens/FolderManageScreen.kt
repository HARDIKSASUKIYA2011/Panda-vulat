package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderSpecial
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.VaultFolder
import com.example.localization.AppLanguage
import com.example.localization.Strings
import com.example.ui.components.ConfirmDeleteDialog
import com.example.ui.components.CreateFolderDialog
import com.example.ui.components.PandaTopBar
import com.example.ui.navigation.Screen
import com.example.ui.theme.BambooEmerald
import com.example.ui.theme.PandaRose
import com.example.ui.viewmodel.VaultViewModel

@Composable
fun FolderManageScreen(
    viewModel: VaultViewModel,
    language: AppLanguage,
    onBackClick: () -> Unit,
    onOpenFolder: (Screen) -> Unit
) {
    val folders by viewModel.folders.collectAsState()
    var showCreateDialog by remember { mutableStateOf(false) }
    var folderToDelete by remember { mutableStateOf<VaultFolder?>(null) }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            Column(modifier = Modifier.fillMaxSize()) {
                PandaTopBar(
                    title = Strings.get("nav_folders", language),
                    language = language,
                    onBackClick = onBackClick
                )

                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(folders, key = { it.id }) { folder ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    when (folder.type) {
                                        "PHOTO" -> onOpenFolder(Screen.Photos(folder.id))
                                        "VIDEO" -> onOpenFolder(Screen.Videos(folder.id))
                                        "DOCUMENT" -> onOpenFolder(Screen.Documents(folder.id))
                                        else -> onOpenFolder(Screen.Files(folder.id))
                                    }
                                }
                                .testTag("folder_card_${folder.id}"),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(48.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(BambooEmerald.copy(alpha = 0.15f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = if (folder.isSystem) Icons.Default.FolderSpecial else Icons.Default.Folder,
                                        contentDescription = null,
                                        tint = BambooEmerald,
                                        modifier = Modifier.size(28.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.width(16.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = folder.name,
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                    )
                                    Text(
                                        text = if (folder.isSystem) "System Folder" else "Custom Folder",
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    )
                                }

                                if (!folder.isSystem) {
                                    IconButton(onClick = { folderToDelete = folder }) {
                                        Icon(
                                            imageVector = Icons.Default.Delete,
                                            contentDescription = "Delete Folder",
                                            tint = PandaRose
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Create Folder FAB
            FloatingActionButton(
                onClick = { showCreateDialog = true },
                containerColor = BambooEmerald,
                contentColor = Color.White,
                shape = CircleShape,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(24.dp)
                    .testTag("create_folder_fab")
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "Create Folder", modifier = Modifier.size(28.dp))
            }
        }
    }

    if (showCreateDialog) {
        CreateFolderDialog(
            language = language,
            onDismiss = { showCreateDialog = false },
            onConfirm = { name ->
                viewModel.createFolder(name)
                showCreateDialog = false
            }
        )
    }

    folderToDelete?.let { folder ->
        ConfirmDeleteDialog(
            title = "Delete Folder",
            message = "Are you sure you want to delete folder \"${folder.name}\"?",
            language = language,
            onDismiss = { folderToDelete = null },
            onConfirm = {
                viewModel.deleteFolder(folder)
                folderToDelete = null
            }
        )
    }
}
