package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PlayCircleFilled
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.VaultItem
import com.example.localization.AppLanguage
import com.example.localization.Strings
import com.example.ui.components.ConfirmDeleteDialog
import com.example.ui.components.CreateFolderDialog
import com.example.ui.components.FolderSelectDialog
import com.example.ui.components.MultiSelectActionBar
import com.example.ui.components.PandaTopBar
import com.example.ui.components.RenameDialog
import com.example.ui.theme.BambooEmerald
import com.example.ui.theme.PandaCyan
import com.example.ui.viewmodel.VaultViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun VideoVaultScreen(
    viewModel: VaultViewModel,
    folderId: Long?,
    language: AppLanguage,
    onBackClick: () -> Unit,
    onVideoClick: (Long) -> Unit
) {
    val context = LocalContext.current
    val allVideos by viewModel.videos.collectAsState()
    val folders by viewModel.folders.collectAsState()
    val selectedIds by viewModel.selectedItemIds.collectAsState()

    val displayVideos = if (folderId != null) {
        allVideos.filter { it.folderId == folderId }
    } else {
        allVideos
    }

    var itemToRename by remember { mutableStateOf<VaultItem?>(null) }
    var itemToMove by remember { mutableStateOf<VaultItem?>(null) }
    var itemToDelete by remember { mutableStateOf<VaultItem?>(null) }
    var showFolderSelectDialog by remember { mutableStateOf(false) }
    var showCreateFolderDialog by remember { mutableStateOf(false) }
    var showMultiDeleteConfirm by remember { mutableStateOf(false) }

    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia()
    ) { uris ->
        if (uris.isNotEmpty()) {
            viewModel.importUris(uris, folderId)
        }
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            Column(modifier = Modifier.fillMaxSize()) {
                PandaTopBar(
                    title = Strings.get("nav_videos", language),
                    language = language,
                    onBackClick = onBackClick
                )

                if (selectedIds.isNotEmpty()) {
                    MultiSelectActionBar(
                        selectedCount = selectedIds.size,
                        language = language,
                        onClearSelection = { viewModel.clearSelection() },
                        onSelectAll = { viewModel.selectAll(displayVideos.map { it.id }) },
                        onMoveSelected = { showFolderSelectDialog = true },
                        onRestoreSelected = { viewModel.restoreSelectedToDownloads(context) },
                        onDeleteSelected = { showMultiDeleteConfirm = true }
                    )
                }

                if (displayVideos.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.VideoLibrary,
                                contentDescription = null,
                                tint = PandaCyan.copy(alpha = 0.5f),
                                modifier = Modifier.size(72.dp)
                            )
                            Text(
                                text = Strings.get("empty_videos_title", language),
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                modifier = Modifier.padding(top = 16.dp)
                            )
                            Text(
                                text = Strings.get("empty_videos_desc", language),
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                ),
                                modifier = Modifier.padding(top = 8.dp)
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(displayVideos, key = { it.id }) { video ->
                            val isSelected = selectedIds.contains(video.id)
                            VideoListItem(
                                item = video,
                                isSelected = isSelected,
                                language = language,
                                onClick = {
                                    if (selectedIds.isNotEmpty()) {
                                        viewModel.toggleSelection(video.id)
                                    } else {
                                        onVideoClick(video.id)
                                    }
                                },
                                onLongClick = { viewModel.toggleSelection(video.id) },
                                onRename = { itemToRename = video },
                                onMove = { itemToMove = video },
                                onRestore = { viewModel.restoreItemToDownloads(video, context) },
                                onDelete = { itemToDelete = video }
                            )
                        }
                    }
                }
            }

            // Floating Action Button
            FloatingActionButton(
                onClick = {
                    videoPickerLauncher.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                    )
                },
                containerColor = PandaCyan,
                contentColor = Color.White,
                shape = CircleShape,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(24.dp)
                    .testTag("import_videos_fab")
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Import Videos",
                    modifier = Modifier.size(28.dp)
                )
            }
        }
    }

    itemToRename?.let { video ->
        RenameDialog(
            initialName = video.fileName,
            language = language,
            onDismiss = { itemToRename = null },
            onConfirm = { newName ->
                viewModel.renameItem(video.id, newName)
                itemToRename = null
            }
        )
    }

    itemToMove?.let { video ->
        FolderSelectDialog(
            folders = folders,
            language = language,
            onDismiss = { itemToMove = null },
            onSelectFolder = { targetFolderId ->
                viewModel.moveItemToFolder(video.id, targetFolderId)
                itemToMove = null
            },
            onCreateFolder = {
                itemToMove = null
                showCreateFolderDialog = true
            }
        )
    }

    itemToDelete?.let { video ->
        ConfirmDeleteDialog(
            title = Strings.get("delete", language),
            message = Strings.get("file_deleted", language),
            language = language,
            onDismiss = { itemToDelete = null },
            onConfirm = {
                viewModel.softDelete(video.id)
                itemToDelete = null
            }
        )
    }

    if (showFolderSelectDialog) {
        FolderSelectDialog(
            folders = folders,
            language = language,
            onDismiss = { showFolderSelectDialog = false },
            onSelectFolder = { targetFolderId ->
                viewModel.moveSelectedToFolder(targetFolderId)
                showFolderSelectDialog = false
            },
            onCreateFolder = {
                showFolderSelectDialog = false
                showCreateFolderDialog = true
            }
        )
    }

    if (showCreateFolderDialog) {
        CreateFolderDialog(
            language = language,
            onDismiss = { showCreateFolderDialog = false },
            onConfirm = { folderName ->
                viewModel.createFolder(folderName, "VIDEO")
                showCreateFolderDialog = false
            }
        )
    }

    if (showMultiDeleteConfirm) {
        ConfirmDeleteDialog(
            title = Strings.get("delete", language),
            message = Strings.get("file_deleted", language),
            language = language,
            onDismiss = { showMultiDeleteConfirm = false },
            onConfirm = {
                viewModel.softDeleteSelected()
                showMultiDeleteConfirm = false
            }
        )
    }
}

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
fun VideoListItem(
    item: VaultItem,
    isSelected: Boolean,
    language: AppLanguage,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onRename: () -> Unit,
    onMove: () -> Unit,
    onRestore: () -> Unit,
    onDelete: () -> Unit
) {
    var showMenu by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .border(
                width = if (isSelected) 2.dp else 0.dp,
                color = if (isSelected) BambooEmerald else Color.Transparent,
                shape = RoundedCornerShape(16.dp)
            )
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .testTag("video_item_${item.id}"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(54.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(PandaCyan.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                if (isSelected) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Selected",
                        tint = BambooEmerald,
                        modifier = Modifier.size(30.dp)
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Play",
                        tint = PandaCyan,
                        modifier = Modifier.size(32.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.fileName,
                    style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.SemiBold),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row {
                    Text(
                        text = formatFileSize(item.fileSize),
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )
                    Text(
                        text = " • " + SimpleDateFormat("MMM d, yyyy", Locale.getDefault()).format(Date(item.createdAt)),
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )
                }
            }

            Box {
                IconButton(onClick = { showMenu = true }) {
                    Icon(
                        imageVector = Icons.Default.MoreVert,
                        contentDescription = "Options"
                    )
                }

                DropdownMenu(
                    expanded = showMenu,
                    onDismissRequest = { showMenu = false }
                ) {
                    DropdownMenuItem(
                        text = { Text(Strings.get("rename", language)) },
                        onClick = {
                            showMenu = false
                            onRename()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text(Strings.get("move", language)) },
                        onClick = {
                            showMenu = false
                            onMove()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text(Strings.get("restore", language)) },
                        onClick = {
                            showMenu = false
                            onRestore()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text(Strings.get("delete", language)) },
                        onClick = {
                            showMenu = false
                            onDelete()
                        }
                    )
                }
            }
        }
    }
}

fun formatFileSize(bytes: Long): String {
    if (bytes <= 0) return "0 B"
    val units = arrayOf("B", "KB", "MB", "GB", "TB")
    val digitGroups = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt()
    val value = bytes / Math.pow(1024.0, digitGroups.toDouble())
    return String.format(Locale.getDefault(), "%.1f %s", value, units[digitGroups])
}
