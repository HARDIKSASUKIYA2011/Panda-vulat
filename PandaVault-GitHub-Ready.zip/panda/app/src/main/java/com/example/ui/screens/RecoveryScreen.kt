package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.localization.AppLanguage
import com.example.localization.Strings
import com.example.ui.components.PandaTopBar
import com.example.ui.components.PinKeypad
import com.example.ui.theme.BambooEmerald
import com.example.ui.theme.PandaGold
import com.example.ui.theme.PandaRose
import com.example.ui.viewmodel.VaultViewModel

@Composable
fun RecoveryScreen(
    viewModel: VaultViewModel,
    language: AppLanguage,
    onBackClick: () -> Unit
) {
    val storedQuestion = viewModel.securityPrefs.securityQuestion.ifBlank {
        "Default Security Question"
    }

    var answerInput by remember { mutableStateOf("") }
    var isAnswerVerified by remember { mutableStateOf(false) }
    var newPinInput by remember { mutableStateOf("") }
    var confirmPinInput by remember { mutableStateOf("") }
    var step by remember { mutableStateOf(1) } // 1 = Answer, 2 = New PIN, 3 = Confirm
    var errorMessage by remember { mutableStateOf<String?>(null) }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            PandaTopBar(
                title = Strings.get("recovery_title", language),
                language = language,
                onBackClick = onBackClick
            )

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Security Warning Card
                Card(
                    colors = CardDefaults.cardColors(containerColor = PandaGold.copy(alpha = 0.12f)),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = null,
                            tint = PandaGold,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.size(12.dp))
                        Text(
                            text = Strings.get("recovery_warning", language),
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                if (!isAnswerVerified) {
                    Text(
                        text = Strings.get("security_question", language),
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        modifier = Modifier.align(Alignment.Start)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = storedQuestion,
                        style = MaterialTheme.typography.bodyLarge.copy(
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.primary
                        ),
                        modifier = Modifier.align(Alignment.Start)
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    OutlinedTextField(
                        value = answerInput,
                        onValueChange = {
                            answerInput = it
                            errorMessage = null
                        },
                        label = { Text(Strings.get("security_answer", language)) },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("recovery_answer_input")
                    )

                    if (errorMessage != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = errorMessage!!,
                            color = PandaRose,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Button(
                        onClick = {
                            if (viewModel.verifyRecoveryAnswer(answerInput)) {
                                isAnswerVerified = true
                            } else {
                                errorMessage = "Incorrect answer or recovery key."
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = BambooEmerald),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("verify_recovery_button")
                    ) {
                        Text(Strings.get("confirm", language), fontWeight = FontWeight.Bold)
                    }
                } else {
                    // Answer verified! Now set new PIN
                    Text(
                        text = if (step == 2) Strings.get("create_pin", language) else Strings.get("confirm_pin", language),
                        style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold)
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    val currentPin = if (step == 2) newPinInput else confirmPinInput

                    PinKeypad(
                        currentPin = currentPin,
                        maxDigits = 6,
                        onPinChange = { pin ->
                            if (step == 2) {
                                newPinInput = pin
                                if (pin.length == 6) {
                                    step = 3
                                }
                            } else {
                                confirmPinInput = pin
                                if (pin.length == newPinInput.length) {
                                    if (pin == newPinInput) {
                                        viewModel.resetPin(pin)
                                    } else {
                                        errorMessage = Strings.get("pin_mismatch", language)
                                        confirmPinInput = ""
                                    }
                                }
                            }
                        },
                        language = language
                    )

                    if (step == 2 && newPinInput.length >= 4) {
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = { step = 3 },
                            colors = ButtonDefaults.buttonColors(containerColor = BambooEmerald),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(Strings.get("confirm", language), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
